# Novus-agenti (Omni Claw) — Active

<!-- Blank template. User fills this in / model updates it as work happens. Don't guess content — if a field is unknown, leave it unknown rather than inferring from a similarly-named old project. -->

## What it is
(repo link, stack, purpose — fill in)

## State
(current milestones / what's built / what's not)

## Next step
(concrete next action)
